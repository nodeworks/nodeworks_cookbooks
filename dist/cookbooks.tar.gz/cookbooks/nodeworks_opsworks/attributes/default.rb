default['slack']['webhook_url'] = 'https://hooks.slack.com/services/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'
node.default[:alb_helper][:connection_draining_timeout] = 750
node.default[:alb_helper][:state_check_frequency] = 30