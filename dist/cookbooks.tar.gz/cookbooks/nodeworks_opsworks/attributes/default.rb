default['slack']['webhook_url'] = 'https://hooks.slack.com/services/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'
default[:alb_helper][:connection_draining_timeout] = 750
default[:alb_helper][:state_check_frequency] = 30