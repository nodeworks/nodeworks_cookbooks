## 0.1.2 (09 Nov 2016)

BUGFIXES:

  * Correct renewal script quotes for shell variable expansion #11

## 0.1.1 (28 Sep 2016)

BUGFIXES:

  * Bypass http access restrictions for certbot webroot #10

## 0.1.0 (09 Aug 2016)

  * Initial release
